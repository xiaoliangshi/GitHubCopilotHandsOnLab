﻿using System;
using System.Collections.Generic;

namespace System.Numbers
{
    public class PrimeService
    {
    }
}
